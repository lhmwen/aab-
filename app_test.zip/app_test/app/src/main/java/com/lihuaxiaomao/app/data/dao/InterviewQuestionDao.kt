package com.lihuaxiaomao.app.data.dao

import androidx.room.*
import com.lihuaxiaomao.app.data.entity.InterviewQuestion
import kotlinx.coroutines.flow.Flow

@Dao
interface InterviewQuestionDao {
    @Query("SELECT * FROM interview_questions WHERE groupId = :groupId ORDER BY sortOrder ASC")
    fun getQuestionsByGroup(groupId: String): Flow<List<InterviewQuestion>>

    @Query("SELECT * FROM interview_questions WHERE id = :id")
    suspend fun getQuestionById(id: String): InterviewQuestion?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: InterviewQuestion)

    @Update
    suspend fun updateQuestion(question: InterviewQuestion)

    @Delete
    suspend fun deleteQuestion(question: InterviewQuestion)

    @Query("UPDATE interview_questions SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun updateQuestionSortOrder(id: String, sortOrder: Int)
}