package com.lihuaxiaomao.app.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.lihuaxiaomao.app.data.converter.Converters
import com.lihuaxiaomao.app.data.dao.*
import com.lihuaxiaomao.app.data.entity.*

@Database(
    entities = [
        Note::class,
        NoteGroup::class,
        InterviewGroup::class,
        InterviewQuestion::class,
        Document::class,
        ImageAlbum::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun noteGroupDao(): NoteGroupDao
    abstract fun interviewGroupDao(): InterviewGroupDao
    abstract fun interviewQuestionDao(): InterviewQuestionDao
    abstract fun documentDao(): DocumentDao
    abstract fun imageAlbumDao(): ImageAlbumDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lihua_xiaomao_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}