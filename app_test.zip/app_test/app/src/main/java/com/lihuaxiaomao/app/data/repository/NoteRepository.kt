package com.lihuaxiaomao.app.data.repository

import com.lihuaxiaomao.app.data.dao.NoteDao
import com.lihuaxiaomao.app.data.dao.NoteGroupDao
import com.lihuaxiaomao.app.data.entity.Note
import com.lihuaxiaomao.app.data.entity.NoteGroup
import kotlinx.coroutines.flow.Flow
import java.util.*

class NoteRepository(
    private val noteDao: NoteDao,
    private val noteGroupDao: NoteGroupDao
) {
    fun getNotesWithoutGroup(): Flow<List<Note>> = noteDao.getNotesWithoutGroup()
    
    fun getNotesByGroup(groupId: String): Flow<List<Note>> = noteDao.getNotesByGroup(groupId)
    
    fun getAllNoteGroups(): Flow<List<NoteGroup>> = noteGroupDao.getAllNoteGroups()
    
    suspend fun getNoteById(id: String): Note? = noteDao.getNoteById(id)
    
    suspend fun getNoteGroupById(id: String): NoteGroup? = noteGroupDao.getNoteGroupById(id)
    
    suspend fun insertNote(note: Note) = noteDao.insertNote(note)
    
    suspend fun updateNote(note: Note) = noteDao.updateNote(note)
    
    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)
    
    suspend fun insertNoteGroup(noteGroup: NoteGroup) = noteGroupDao.insertNoteGroup(noteGroup)
    
    suspend fun updateNoteGroup(noteGroup: NoteGroup) = noteGroupDao.updateNoteGroup(noteGroup)
    
    suspend fun deleteNoteGroup(noteGroup: NoteGroup) = noteGroupDao.deleteNoteGroup(noteGroup)
    
    suspend fun createNote(title: String, content: String, groupId: String? = null): Note {
        val note = Note(
            id = UUID.randomUUID().toString(),
            title = title,
            content = content,
            groupId = groupId,
            sortOrder = 0,
            createdAt = Date(),
            updatedAt = Date()
        )
        insertNote(note)
        return note
    }
    
    suspend fun createNoteGroup(name: String): NoteGroup {
        val noteGroup = NoteGroup(
            id = UUID.randomUUID().toString(),
            name = name,
            sortOrder = 0,
            createdAt = Date(),
            updatedAt = Date()
        )
        insertNoteGroup(noteGroup)
        return noteGroup
    }
}