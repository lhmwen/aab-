package com.lihuaxiaomao.app.data.dao

import androidx.room.*
import com.lihuaxiaomao.app.data.entity.ImageAlbum
import kotlinx.coroutines.flow.Flow

@Dao
interface ImageAlbumDao {
    @Query("SELECT * FROM image_albums ORDER BY sortOrder ASC")
    fun getAllImageAlbums(): Flow<List<ImageAlbum>>

    @Query("SELECT * FROM image_albums WHERE id = :id")
    suspend fun getImageAlbumById(id: String): ImageAlbum?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImageAlbum(imageAlbum: ImageAlbum)

    @Update
    suspend fun updateImageAlbum(imageAlbum: ImageAlbum)

    @Delete
    suspend fun deleteImageAlbum(imageAlbum: ImageAlbum)

    @Query("UPDATE image_albums SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun updateImageAlbumSortOrder(id: String, sortOrder: Int)
}