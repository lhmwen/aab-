package com.lihuaxiaomao.app.data.repository

import com.lihuaxiaomao.app.data.dao.InterviewGroupDao
import com.lihuaxiaomao.app.data.dao.InterviewQuestionDao
import com.lihuaxiaomao.app.data.entity.InterviewGroup
import com.lihuaxiaomao.app.data.entity.InterviewQuestion
import kotlinx.coroutines.flow.Flow
import java.util.*

class InterviewRepository(
    private val interviewGroupDao: InterviewGroupDao,
    private val interviewQuestionDao: InterviewQuestionDao
) {
    fun getAllInterviewGroups(): Flow<List<InterviewGroup>> = interviewGroupDao.getAllInterviewGroups()
    
    fun getQuestionsByGroup(groupId: String): Flow<List<InterviewQuestion>> = 
        interviewQuestionDao.getQuestionsByGroup(groupId)
    
    suspend fun getInterviewGroupById(id: String): InterviewGroup? = 
        interviewGroupDao.getInterviewGroupById(id)
    
    suspend fun getQuestionById(id: String): InterviewQuestion? = 
        interviewQuestionDao.getQuestionById(id)
    
    suspend fun insertInterviewGroup(group: InterviewGroup) = 
        interviewGroupDao.insertInterviewGroup(group)
    
    suspend fun updateInterviewGroup(group: InterviewGroup) = 
        interviewGroupDao.updateInterviewGroup(group)
    
    suspend fun deleteInterviewGroup(group: InterviewGroup) = 
        interviewGroupDao.deleteInterviewGroup(group)
    
    suspend fun insertQuestion(question: InterviewQuestion) = 
        interviewQuestionDao.insertQuestion(question)
    
    suspend fun updateQuestion(question: InterviewQuestion) = 
        interviewQuestionDao.updateQuestion(question)
    
    suspend fun deleteQuestion(question: InterviewQuestion) = 
        interviewQuestionDao.deleteQuestion(question)
    
    suspend fun createInterviewGroup(name: String): InterviewGroup {
        val group = InterviewGroup(
            id = UUID.randomUUID().toString(),
            name = name,
            sortOrder = 0,
            createdAt = Date(),
            updatedAt = Date()
        )
        insertInterviewGroup(group)
        return group
    }
    
    suspend fun createQuestion(question: String, answer: String, groupId: String): InterviewQuestion {
        val interviewQuestion = InterviewQuestion(
            id = UUID.randomUUID().toString(),
            question = question,
            answer = answer,
            groupId = groupId,
            sortOrder = 0,
            createdAt = Date(),
            updatedAt = Date()
        )
        insertQuestion(interviewQuestion)
        return interviewQuestion
    }
}