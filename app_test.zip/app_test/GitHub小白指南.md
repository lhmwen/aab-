# GitHub 小白完全指南

## 🎯 什么是GitHub？
GitHub就像一个"代码网盘"，可以免费存储和分享代码项目，还能自动帮您构建APK文件。

## 📝 第一步：注册GitHub账号

### 1. 访问GitHub官网
- 打开浏览器，访问：https://github.com
- 点击右上角绿色的"Sign up"按钮

### 2. 填写注册信息
- **用户名**：选择一个喜欢的用户名（英文+数字）
- **邮箱**：填写您的邮箱地址
- **密码**：设置一个安全的密码
- 完成人机验证

### 3. 验证邮箱
- 查看邮箱收到的验证邮件
- 点击邮件中的验证链接
- 返回GitHub完成注册

## 📁 第二步：创建新仓库（项目）

### 1. 创建仓库
- 登录GitHub后，点击右上角的"+"号
- 选择"New repository"
- 填写仓库信息：
  - **Repository name**：输入 `lihua-xiaomao-app`
  - **Description**：输入 `狸花小猫Android应用`
  - 选择"Public"（公开）
  - 勾选"Add a README file"
- 点击绿色的"Create repository"按钮

## 📤 第三步：上传项目文件

### 方法一：网页上传（推荐给小白）

#### 1. 准备文件
- 打开您电脑上的 `d:\小鳄\kaifa\app_test` 文件夹
- 选择所有文件和文件夹（Ctrl+A）
- 压缩成ZIP文件（右键 → 发送到 → 压缩文件夹）

#### 2. 上传到GitHub
- 在GitHub仓库页面，点击"uploading an existing file"
- 或者点击"Add file" → "Upload files"
- 拖拽ZIP文件到页面中，或点击"choose your files"选择文件
- 等待上传完成

#### 3. 提交更改
- 在页面底部的"Commit changes"区域
- 在"Commit message"中输入：`上传狸花小猫应用项目`
- 点击绿色的"Commit changes"按钮

### 方法二：逐个上传文件

#### 1. 上传主要文件
依次上传以下重要文件：
- `build.gradle`
- `settings.gradle`
- `gradlew`
- `gradlew.bat`

#### 2. 创建文件夹并上传
- 点击"Create new file"
- 输入 `app/build.gradle`（这会自动创建app文件夹）
- 复制粘贴文件内容
- 提交更改

#### 3. 继续上传其他文件
重复上述步骤，上传所有必要的文件和文件夹

## 🔧 第四步：设置自动构建

### 1. 创建GitHub Actions
- 在仓库中，点击"Actions"标签
- 选择"set up a workflow yourself"
- 删除默认内容，**完整复制粘贴**以下内容（注意不要有多余的空格）：

```yaml
name: Build Android APK

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'

    - name: Setup Android SDK
      uses: android-actions/setup-android@v3

    - name: Grant execute permission for gradlew
      run: chmod +x gradlew

    - name: Build with Gradle
      run: ./gradlew assembleDebug

    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: app-debug
        path: app/build/outputs/apk/debug/app-debug.apk
```

**⚠️ 重要提示：**
- 确保复制时没有多余的空格
- 文件名必须以 `.yml` 结尾
- 缩进必须使用空格，不能用Tab键

### 2. 保存并运行
- 点击"Start commit"
- 输入提交信息：`添加自动构建配置`
- 点击"Commit new file"
- GitHub会自动开始构建APK

## 📱 第五步：下载APK

### 1. 查看构建状态
- 点击"Actions"标签
- 查看构建进度（通常需要5-15分钟）
- 等待显示绿色的✅表示成功

### 2. 下载APK文件
- 点击成功的构建任务
- 在"Artifacts"部分找到"app-debug"
- 点击下载ZIP文件
- 解压得到APK文件

## 📱 第六步：安装到手机

### 1. 传输APK到手机
- 通过QQ、微信发送给自己
- 或用数据线复制到手机
- 或通过云盘下载到手机

### 2. 安装APK
- 在手机设置中允许"未知来源"安装
- 点击APK文件
- 按提示完成安装

## 🎯 小贴士

### 常见问题
1. **上传失败**：检查网络连接，文件不要太大
2. **构建失败**：检查文件结构是否完整
3. **无法下载**：确保构建成功（绿色✅）

### 注意事项
- GitHub免费账号有使用限制，但对个人项目足够
- 构建过程需要时间，请耐心等待
- 保持文件结构完整，不要遗漏重要文件

## 🆘 需要帮助？
如果在任何步骤遇到问题：
1. 截图发送错误信息
2. 说明在哪一步遇到困难
3. 描述具体的错误提示